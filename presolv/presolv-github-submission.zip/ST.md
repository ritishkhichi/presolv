# Loom recording script (~5 minutes)

Use this outline when recording your submission walkthrough.

## 1. Demo (2 min)

1. Open terminal in project root, activate venv.
2. Show `.env` has `MOCK_AGENT=true` (do **not** show API key on screen).
3. Run `python cli.py` — point out `Mode: mock (offline)`.
4. Ask: `What's on my calendar tomorrow?`
5. Type `/reset`, then `/quit`.

## 2. Examples (1 min)

1. Run `python examples/run_all.py`.
2. Briefly scroll through output — mention 8 examples cover happy path, multi-turn, errors, ambiguity, NOT_FOUND, no-tool.

## 3. Design decisions (1.5 min)

Pick 2–3:

- **Manual tool loop** — Gemini AFC disabled; we control tool execution and `ToolResult` errors.
- **Five granular tools** — calendar read/write split; easier recovery than one mega-tool.
- **Mocked tools + mock agent** — brief requires fake APIs; `MOCK_AGENT` for offline demos when quota exhausted.
- **CLI-only scope** — no UI; examples are the eval suite.

## 4. Improve with more time (30 sec)

- Real Calendar/CRM APIs, retry/circuit breaker, eval CI with golden transcripts, live Gemini when quota returns.

## 5. What didn't work (30 sec)

- Gemini quota exhausted during testing → added `MOCK_AGENT`.
- Wrong import in `_runner.py` (fixed).
- Mock routing needed tuning for June 20 / unit conversion queries.

---

**You record this** — paste the Loom link in your submission email.
